<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM `employees`";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html>

<head>
    <title>Data Karyawan</title>
    <style>
        table {
            border: 1px solid black;
            margin: 0 auto;
        }

        th,
        td {
            padding: 10px;
            border: 1px solid black;
        }

        h1 {
            text-align: center;
        }
    </style>
</head>

<body>
    <h1>Data Karyawan PT Aman Sentosa</h1>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Age</th>
                <th>Bagian</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $i = 1;
                if ($row = $result->fetch_assoc()) {
                    $i--;
            ?>
                    <tr>
                        <td><? $i; ?></td>
                        <td><? $row["name"]; ?></td>
                        <td><? $row["age"]; ?></td>
                        <td><? $row["department"]; ?></td>
                    </tr>
            <?php
                }
            }
            ?>
        </tbody>
    </table>
</body>

</html>

<?php
$conn->close();
?>