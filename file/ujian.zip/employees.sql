-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2023 at 12:27 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ujian`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `age`, `department`) VALUES
(1, 'John Smith', 35, 'Sales'),
(2, 'Jane Doe', 28, 'Marketing'),
(3, 'Bob Johnson', 42, 'Engineering'),
(4, 'Mary Brown', 23, 'Finance'),
(5, 'David Lee', 31, 'IT'),
(6, 'Karen Kim', 45, 'HR'),
(7, 'Steve Chen', 37, 'Sales'),
(8, 'Amy Chen', 27, 'Marketing'),
(9, 'Michael Johnson', 49, 'Engineering'),
(10, 'Jessica Huang', 25, 'Finance'),
(11, 'Jason Park', 34, 'IT'),
(12, 'Emily Davis', 40, 'HR'),
(13, 'Tom Wong', 33, 'Sales'),
(14, 'Nancy Wang', 29, 'Marketing'),
(15, 'Alex Li', 43, 'Engineering');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
