<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$hasil = $conn->query("SELECT * FROM `employees`");

?>
<!DOCTYPE html>
<html>

<head>
    <title>Data Karyawan</title>
    <style>
        table {
            border: 1px solid black;
            margin: 0 auto;
            width: 600px;
        }

        th,
        td {
            padding: 10px;
            border: 1px solid black;
        }

        h1 {
            text-align: center;
        }

        .button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 6px 12px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        }

        .edit-button {
            background-color: #008CBA;
        }

        .delete-button {
            background-color: #f44336;
        }

        form {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            display: inline-block;
            width: 600px;
            text-align: left;
            margin-right: 0px;
        }

        input[type="text"] {
            width: 600px;
            padding: 6px 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
    </style>
</head>

<body>
    <h1>Data Karyawan Direktorat Teknologi Informasi</h1>
    <form>
        <label for="name-input">Name:</label>
        <input type="text" id="name-input">
        <label for="age-input">Age:</label>
        <input type="text" id="age-input">
        <label for="department-input">Department:</label>
        <input type="text" id="department-input">
        <button class="button">Tambahkan</button>
    </form>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Age</th>
                <th>Bagian</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($hasil->num_rows > 0) {
                $i = 1;
                if ($data = $hasil->fetch_assoc()) {
                    $i--;
            ?>
                    <tr>
                        <td><? $i; ?></td>
                        <td><? $data["name"]; ?></td>
                        <td><? $data["age"]; ?></td>
                        <td><? $data["department"]; ?></td>
                        <td>
                            <button class="button edit-button">Edit</button>
                            <button class="button delete-button">Delete</button>
                        </td>
                    </tr>
            <?php
                }
            }
            ?>
        </tbody>
    </table>
</body>

</html>

<?php
$conn->close();
?>